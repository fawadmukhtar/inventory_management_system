"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var employee_record_service_1 = require('./employee-record.service');
var common_1 = require('@angular/common');
require('rxjs/add/operator/switchMap');
var AddNewEmployeeComponent = (function () {
    function AddNewEmployeeComponent(employeeRecordService, router, route, location) {
        this.employeeRecordService = employeeRecordService;
        this.router = router;
        this.route = route;
        this.location = location;
        this.checkUpdate = false;
    }
    AddNewEmployeeComponent.prototype.onSubmit = function (event) {
        event.preventDefault();
        this.newEmployee = {
            id: this.id, firstName: this.firstName, lastName: this.lastName,
            dob: this.dob, dojoining: this.dojoining, leaveAvail: this.leaveAvail,
            phone: this.phone, age: this.age, jobDescp: this.jobDescp
        };
        this.employeeRecordService.create(this.newEmployee).then();
        // this.employeeRecordService.create(this.id, this.firstName, this.lastName,
        // 	this.dob, this.dojoining, this.leaveAvail, this.phone, this.age, this.jobDescp)
        // 	.then();
        this.router.navigate(['/employeesRecord']);
    };
    AddNewEmployeeComponent.prototype.onUpdate = function (event) {
        var _this = this;
        event.preventDefault();
        this.employeeRecordService.update(this.selectedEmployee)
            .then(function () { return _this.goBack(); });
    };
    AddNewEmployeeComponent.prototype.ngOnInit = function () {
        var _this = this;
        // this.route.snapshot.params['id']); the route.snapshot provide the initial value
        // of the parameters. You can access the parameters directly without subscribing or 
        // adding observable operators. it much simpler to write and read 
        // console.log(this.route.snapshot);
        if (this.route.snapshot.params['id']) {
            this.route.params
                .switchMap(function (params) { return _this.employeeRecordService
                .getEmployee(+params['id']); })
                .subscribe(function (employee) {
                _this.selectedEmployee = employee;
                // after first compilation of code and open window in browser
                // uncomment below three ubline, in computer compilation it 
                // shows error while in browser does not showing error
                // this.selectedEmployee.dob = this.formatDate(employee.dob);
                // this.selectedEmployee.dojoining = this
                // .formatDate(employee.dojoining);
                _this.checkUpdate = true;
            });
        }
    };
    // get diagnostic() {
    // 	return JSON.stringify(this.selectedEmployee.firstName);
    // }  // this was only for testing, is our ngModel is working or not ?
    AddNewEmployeeComponent.prototype.goBack = function () {
        this.location.back();
    };
    AddNewEmployeeComponent.prototype.formatDate = function (myDate) {
        var newDate = new Date(myDate);
        var year = newDate.getFullYear();
        var month = newDate.getMonth() + 1;
        var day = newDate.getDate();
        var newDay = '';
        var newMonth = '';
        if (day < 10) {
            newDay = '0' + day;
        }
        else {
            newDay = '' + day;
        }
        if (month < 10) {
            newMonth = '0' + month;
        }
        else {
            newMonth = '' + month;
        }
        var result = year + "-" + newMonth + "-" + newDay;
        return result;
    };
    AddNewEmployeeComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'add-new-employee',
            templateUrl: './add-new-employee.component.html',
            styleUrls: ['./add-new-employee.component.css']
        }), 
        __metadata('design:paramtypes', [employee_record_service_1.EmployeeRecordService, router_1.Router, router_1.ActivatedRoute, common_1.Location])
    ], AddNewEmployeeComponent);
    return AddNewEmployeeComponent;
}());
exports.AddNewEmployeeComponent = AddNewEmployeeComponent;
//# sourceMappingURL=add-new-employee.component.js.map