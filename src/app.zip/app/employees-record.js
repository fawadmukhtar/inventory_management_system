"use strict";
var EmployeesRecord = (function () {
    function EmployeesRecord(id, firstName, lastName, dob, // data type for dob should be date
        dojoining, leaveAvail, phone, age, jobDescp) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.dojoining = dojoining;
        this.leaveAvail = leaveAvail;
        this.phone = phone;
        this.age = age;
        this.jobDescp = jobDescp;
    }
    return EmployeesRecord;
}());
exports.EmployeesRecord = EmployeesRecord;
//# sourceMappingURL=employees-record.js.map