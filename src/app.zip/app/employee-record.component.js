"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
// import { EMPLOYEES }  from './mock-employees';
var employee_record_service_1 = require('./employee-record.service');
var router_1 = require('@angular/router');
var EmployeeRecordComponent = (function () {
    // employeesLength: number;
    // totalItem:any;
    // currentEmployee: EmployeeRecordService;
    // currentEmployeeCheck = false;
    function EmployeeRecordComponent(employeeRecordService, router) {
        this.employeeRecordService = employeeRecordService;
        this.router = router;
        this.title = 'Employees Record';
    }
    // fullDetail(currentEmployee:any){
    // 	this.currentEmployeeCheck = true;
    // 	this.currentEmployee = currentEmployee;
    // }
    EmployeeRecordComponent.prototype.getEmployee = function () {
        var _this = this;
        this.employeeRecordService.getEmployees().
            then(function (employees) {
            _this.employees = employees;
            // this.employeesLength = employees.length;
            // if(this.employeesLength > 10){
            // 	this.employees = this.employees.slice(0, 10);
            // 	console.log(this.employees);
            // }
        });
        //console.log(this.employeesLength); // if we assigne value here it will
        // display undefined because this will execute before the then response
    };
    EmployeeRecordComponent.prototype.removeRecord = function (id) {
        var _this = this;
        this.employeeRecordService.deleteEmployee(id)
            .then(function () {
            return _this.employees = _this.employees
                .filter(function (employee) { return employee.id !== id; });
        });
    };
    // when doing pagination
    // public getServerData(event:any){
    // 	this.employeeRecordService.getdata(event).subscribe(
    // 		response =>{
    // 			if(response.error) { 
    // 				alert('Server Error');
    // 			} else {
    // 				this.employees = response.employees;
    // 				this.totalItem = response.totalItems;
    // 			}
    // 		},
    // 		error =>{
    // 			alert('Server error');
    // 		}
    // 	);
    // 	return event;
    // }
    EmployeeRecordComponent.prototype.ngOnInit = function () {
        this.getEmployee();
    };
    EmployeeRecordComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'employee-record',
            templateUrl: './employee-record.component.html',
            styleUrls: ['./employee-record.component.css']
        }), 
        __metadata('design:paramtypes', [employee_record_service_1.EmployeeRecordService, router_1.Router])
    ], EmployeeRecordComponent);
    return EmployeeRecordComponent;
}());
exports.EmployeeRecordComponent = EmployeeRecordComponent;
//# sourceMappingURL=employee-record.component.js.map