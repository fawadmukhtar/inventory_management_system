"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
// loading these for loading data from server
var http_1 = require('@angular/http');
require('rxjs/add/operator/toPromise'); // when use http then use toPromise
// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/catch';
// import { Observable } from 'rxjs/Rx';
var EmployeeRecordService = (function () {
    // headers is for extra information, in which formate our data is send, or recive
    function EmployeeRecordService(http) {
        this.http = http;
        this.employeesUrl = 'api/employees';
        this.headers = new http_1.Headers({ 'ContentType': 'application/json' });
    }
    // getEmployees(): Promise<EmployeesRecord[]>{
    // 	return Promise.resolve(EMPLOYEES);
    // }
    EmployeeRecordService.prototype.getEmployees = function () {
        return this.http.get(this.employeesUrl)
            .toPromise()
            .then(function (employees) { return employees.json().data; })
            .catch(this.handleError);
    };
    // public getdata(page:Number):any{
    // 	return this.http.get(`${this.employeesUrl}${page}`)
    // 		.map((response:Response) => response.json())
    // 		.catch((error:any) => Observable.throw(error.json().error) || 'Server Error');
    // }
    // getEmployees(page:Number):any{
    // 	return this.http.get(`${this.employeesUrl}${page}`)
    // 		.map((response:Response) => response.json().data)
    // 		.catch((error:any) => Observable.throw(error.json().error) || 'Server Error');
    // }
    // getEmployee(id:number): Promise<EmployeesRecord>{
    // 	return this.getEmployees()
    // 		.then(employees => employees.find(employee => employee.employeeID == id));
    // }
    EmployeeRecordService.prototype.getEmployee = function (id) {
        var url = this.employeesUrl + "/" + id; // in this url the only that 
        //employee which  id is same with this parameter id
        return this.http.get(url)
            .toPromise()
            .then(function (employee) { return employee.json().data; })
            .catch(this.handleError);
    };
    EmployeeRecordService.prototype.create = function (newEmployee) {
        return this.http
            .post(this.employeesUrl, JSON.stringify(newEmployee), { headers: this.headers })
            .toPromise()
            .then(function (response) { return response.json().data; })
            .catch(this.handleError);
    };
    EmployeeRecordService.prototype.update = function (selectedEmployee) {
        var url = "api/employees/" + selectedEmployee.id;
        // when use variable in url then use these `` not ''
        return this.http
            .put(url, JSON.stringify(selectedEmployee), { headers: this.headers })
            .toPromise()
            .then(function () { return selectedEmployee; })
            .catch(this.handleError);
    };
    EmployeeRecordService.prototype.deleteEmployee = function (id) {
        var url = this.employeesUrl + "/" + id;
        return this.http
            .delete(url, { headers: this.headers })
            .toPromise()
            .then(function () { return null; })
            .catch(this.handleError);
    };
    EmployeeRecordService.prototype.handleError = function (error) {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    };
    EmployeeRecordService = __decorate([
        // when use http then use toPromise
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], EmployeeRecordService);
    return EmployeeRecordService;
}());
exports.EmployeeRecordService = EmployeeRecordService;
//# sourceMappingURL=employee-record.service.js.map