"use strict";
// so still there is no dependency injection, thats why we are not declare injectable
// decorater
var InMemoryDataService = (function () {
    function InMemoryDataService() {
    }
    InMemoryDataService.prototype.createDb = function () {
        var options = { year: 'numeric', month: 'numeric', day: 'numeric' };
        var employees = [
            {
                id: 1,
                firstName: 'Fahad',
                lastName: 'Mukhtar',
                dob: (new Date('3-9-1008')).toLocaleDateString(),
                dojoining: (new Date('12-3-1995')).toLocaleDateString(),
                leaveAvail: 5,
                phone: 3459547704,
                age: 34,
                jobDescp: 'This is my first data'
            },
            {
                id: 2,
                firstName: 'Fawad',
                lastName: 'Mukhtar',
                dob: (new Date('3-9-1008')).toLocaleDateString(),
                dojoining: (new Date('12-3-1995')).toLocaleDateString(),
                leaveAvail: 5,
                phone: 3459547704,
                age: 34,
                jobDescp: 'This is my first data'
            },
            {
                id: 3,
                firstName: 'Saad',
                lastName: 'Mukhtar',
                dob: (new Date('3-9-1008')).toLocaleDateString(),
                dojoining: (new Date('12-3-1995')).toLocaleDateString(),
                leaveAvail: 5,
                phone: 3459547704,
                age: 34,
                jobDescp: 'This is my first data'
            },
            {
                id: 4,
                firstName: 'Bilal',
                lastName: 'Mukhtar',
                dob: (new Date('3-9-1008')).toLocaleDateString(),
                dojoining: (new Date('12-3-1995')).toLocaleDateString(),
                leaveAvail: 5,
                phone: 3459547704,
                age: 34,
                jobDescp: 'This is my first data'
            },
            {
                id: 5,
                firstName: 'Fahad',
                lastName: 'Mukhtar',
                dob: (new Date('3-9-1008')).toLocaleDateString(),
                dojoining: (new Date('12-3-1995')).toLocaleDateString(),
                leaveAvail: 5,
                phone: 3459547704,
                age: 34,
                jobDescp: 'This is my first data'
            },
            {
                id: 6,
                firstName: 'Fawad',
                lastName: 'Mukhtar',
                dob: (new Date('3-9-1008')).toLocaleDateString(),
                dojoining: (new Date('12-3-1995')).toLocaleDateString(),
                leaveAvail: 5,
                phone: 3459547704,
                age: 34,
                jobDescp: 'This is my first data'
            },
            {
                id: 7,
                firstName: 'Saad',
                lastName: 'Mukhtar',
                dob: (new Date('3-9-1008')).toLocaleDateString(),
                dojoining: (new Date('12-3-1995')).toLocaleDateString(),
                leaveAvail: 5,
                phone: 3459547704,
                age: 34,
                jobDescp: 'This is my first data'
            },
            {
                id: 8,
                firstName: 'Bilal',
                lastName: 'Mukhtar',
                dob: (new Date('3-9-1008')).toLocaleDateString(),
                dojoining: (new Date('12-3-1995')).toLocaleDateString(),
                leaveAvail: 5,
                phone: 3459547704,
                age: 34,
                jobDescp: 'This is my first data'
            }, {
                id: 9,
                firstName: 'Fahad',
                lastName: 'Mukhtar',
                dob: (new Date('3-9-1008')).toLocaleDateString(),
                dojoining: (new Date('12-3-1995')).toLocaleDateString(),
                leaveAvail: 5,
                phone: 3459547704,
                age: 34,
                jobDescp: 'This is my first data'
            },
            {
                id: 10,
                firstName: 'Fawad',
                lastName: 'Mukhtar',
                dob: (new Date('3-9-1008')).toLocaleDateString(),
                dojoining: (new Date('12-3-1995')).toLocaleDateString(),
                leaveAvail: 5,
                phone: 3459547704,
                age: 34,
                jobDescp: 'This is my first data'
            }
        ];
        return { employees: employees }; // curly braces is must
    };
    return InMemoryDataService;
}());
exports.InMemoryDataService = InMemoryDataService;
//# sourceMappingURL=in-memory-data.service.js.map