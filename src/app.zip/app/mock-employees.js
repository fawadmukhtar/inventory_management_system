// import { EmployeesRecord } from './employees-record';
// export const EMPLOYEES: EmployeesRecord[] = [
// 	{
// 		employeeID: 1,
// 		firstName: 'Fahad',
// 		lastName: 'Mukhtar',
// 		dob: '19-dec-1991',
// 		dojoining: '19-dec-1995',
// 		leaveAvail: 5,
// 		phone:  3459547704,
// 		age: 34,
// 		jobDescp: 'This is my first data'
// 	},
// 	{
// 		employeeID: 2,
// 		firstName: 'Fawad',
// 		lastName: 'Mukhtar',
// 		dob: '19-dec-1991',
// 		dojoining: '19-dec-1995',
// 		leaveAvail: 5,
// 		phone:  3459547704,
// 		age: 34,
// 		jobDescp: 'This is my first data'
// 	},
// 	{
// 		employeeID: 3,
// 		firstName: 'Saad',
// 		lastName: 'Mukhtar',
// 		dob: '19-dec-1991',
// 		dojoining: '19-dec-1995',
// 		leaveAvail: 5,
// 		phone:  3459547704,
// 		age: 34,
// 		jobDescp: 'This is my first data'
// 	},
// 	{
// 		employeeID: 4,
// 		firstName: 'Bilal',
// 		lastName: 'Mukhtar',
// 		dob: '19-dec-1991',
// 		dojoining: '19-dec-1995',
// 		leaveAvail: 5,
// 		phone:  3459547704,
// 		age: 34,
// 		jobDescp: 'This is my first data'
// 	}
// ]; 
//# sourceMappingURL=mock-employees.js.map